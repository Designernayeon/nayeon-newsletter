# Nayeon Kim Newsletter — Pink Editorial Redesign

## 맥북에서 바로 확인하기

1. ZIP 파일을 다운로드 폴더에 압축 해제합니다.
2. 터미널에서 아래 명령어를 실행합니다.

```bash
cd ~/Downloads/nayeon-newsletter-pink-redesign/nayeon-newsletter
python3 -m http.server 8000 --directory site
```

3. 새 터미널 창에서 브라우저를 엽니다.

```bash
open http://localhost:8000
```

서버 종료: 실행 중인 터미널에서 `Control + C`

## 수정된 핵심 파일

- `site/index.html` — 레퍼런스 기반 메인 페이지 구조와 카피·버튼 구성
- `site/assets/style.css` — 핑크 스트라이프, 에디토리얼 세리프, 하늘 배경, 우표형 구독 카드 디자인
- `automation/build_site.py` — 향후 자동 생성되는 상세·아카이브 페이지도 동일한 디자인 적용
- `site/newsletters/*/index.html` — 현재 아카이브 페이지 디자인 반영

## 구독 폼 연결

`site/index.html`에서 `<form class="sub-form">` 영역을 Beehiiv 또는 스티비 Embed 코드로 교체하면 됩니다.
